import socket

#FUNCTION FOR SENDING CLIENT REQUEST##################
def req(s,command,path,value):
    s.send(b"%s %s HTTP/1.1 \r\n \r\n\r\n%s"%(bytearray(command,"utf"),bytearray(path,"utf"),bytearray(value,"utf")))
    return str(s.recv(4096))[2:]
#####################################################


#ABBREVIATIONS#######################
g = "GET"
p = "PUT"
tP = "/output/temp"
bP = "/output/Pin(39)"
lP = "/input/led"
paths = {"temp" : tP, "button" : bP}
####################################


#TAKE USER INPUT###########
command = input("Command: ")
###########################

while not command == "exit": #exit if user wrote exit
    
    #SET UP CONNECTION TO SERVER######
    s = socket.socket()
    s.connect(("192.168.4.1",80))
    ##################################
    
    
    #PARSE COMMAND AND MAKE SERVER REQUEST############################################
    c, v = command.split(" ")
    if c.lower() == "col":
        response = req(s,p,lP,v)[-1] #send color change request
        print("Command sent")
        
    elif c.lower() == "get":
        response = req(s,g,paths[v],"") #ask for a resource
        if response.split(" ")[1] == "200": #check if status code is okay
            parts = response.split("\\n")
            value = parts[-1]
            print("Command sent succesfully. Value of " + v + " is " + value)
        else:
            print("Command failed. Server responded with: \n" + response)
    #############################################################################
    
    
    #CLOSE CONNECTION AND REQUEST NEW USER INPUT
    s.close()
    command = input("Command: ")
    #############################################