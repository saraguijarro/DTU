## Assignment 4 - Introduction to Cyber Systems


import machine  #import the machine library to comunicate with the board (ex pins)
import network  #import the network library to use the wifi functionality of the board
import socket   #import the socket library which connects two nodes on a network to communicate with each other

ap = network.WLAN (network.AP_IF)  # Create an access point interface of type WLAN
ap.active (True) # Activate the access point
ap.config (essid = 'ESP32-WIFI-NAME') # Define the network SSID (the WiFi network name)
ap.config (authmode = 3, password = 'WiFi-password') # Configure the authentification protocole 3 and set a password

pins = [machine.Pin(i, machine.Pin.IN) for i in (0, 2, 4, 5, 12, 13, 14, 15)] # Initiate the pin list monitored by the program

# The following lines are HTML code :
 # sets a title in the the HTML metadata, 
 # adds text in the heading,
 # creates a table that presents the status of the pins.
html = """<!DOCTYPE html>
<html>  
    <head> <title>ESP32 Pins</title> </head>
    <body> <h1>ESP32 Pins</h1>
        <table border="1"> <tr><th>Pin</th><th>Value</th></tr> %s </table>
    </body>
</html>
"""

addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1] # Create a table containing the information of the address

s = socket.socket() # Create a new socket object
s.bind(addr) # Bind the socket to the given IP address
s.listen(1) # Enable a server to accept one connection

print('listening on', addr) # Print the sentence "listening on" followed by the address

while True:
    cl, addr = s.accept() # Accept a connection and assign the returned paired values (cl,addr) to the new socket object cl and the address addr corresponding
    # As a matter of fact, cl stands for "client" and is a new socket object usable to send and receive data on the connection
    # Moreover, addr corresponds to the address bound to the socket on the other end of the connection
    print('client connected from', addr) # Print the sentence "client connected from" followed by its IP address
    cl_file = cl.makefile('rwb', 0) # Return a file object associated with the client's socket
    # The argument 'rwb' implies that the file is in binary mode ('b'), open for writting ('w') and reading ('r')
    while True:
        line = cl_file.readline() # Read the data in the lines from the created client's socket file
        #print(line)
        if not line or line == b'\r\n': # If the is no data in line, or if it has reached the end of the file
            break # Break the loop
    rows = ['<tr><td>%s</td><td>%d</td></tr>' % (str(p), p.value()) for p in pins] # Inserting the value of the temperature corresponding to the pins into the intial table
    response = html % '\n'.join(rows) # Insert in the HTML's table the values written in the rows defined in the previous line
    cl.send(response) # Send data in the HTML's table to the client's socket
    cl.close() # Mark the client's socket closed