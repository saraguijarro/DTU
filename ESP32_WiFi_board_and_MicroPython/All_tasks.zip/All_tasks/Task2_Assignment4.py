import machine
import network
import socket
import neopixel

address = 24
temp_reg = 5
res_reg = 8

#CODE FOR HARDWARE###############################################
i2c = machine.I2C(scl = machine.Pin(22),sda = machine.Pin(23))
np = neopixel.NeoPixel(machine.Pin(27),3)
pins = [machine.Pin(39, machine.Pin.IN)]

def green(neopixel):
    neopixel[0] = (255,0,0)
    neopixel[1] = (255,0,0)
    neopixel[2] = (255,0,0)
    np.write()

def yellow(neopixel):
    neopixel[0] = (255,255,0)
    neopixel[1] = (255,255,0)
    neopixel[2] = (255,255,0)
    np.write()

def red(neopixel):
    neopixel[0] = (0,255,0)
    neopixel[1] = (0,255,0)
    neopixel[2] = (0,255,0)
    np.write()



def temp_c(data):
    value = data[0] << 8 | data[1]
    temp = (value & 0xFFF) / 16.0
    if value & 0x1000:
        temp -= 256.0
    return temp
#################################################################



#ACTIVATE SERVER WIFI###########################################
ap = network.WLAN( network.AP_IF )
ap.active( True )
ap.config( essid = 'PyWifi' )
ap.config( authmode = 3, password = "12345678")
################################################################


#GENERIC HTML FORM##############################################
html = """<!DOCTYPE  html>
<html>
    <head><title> ESP32  Pins </title></head>
    <body><h1> ESP32  Pins </h1 >
        <table border = "1"><tr><th> Pin </th><th> Value </th></tr> %s  </table>
     </body>
</html>
"""
################################################################


#OPEN SOCKET FOR COMMUNICATION OVER NETWORK########################
s = socket.socket()
s.bind( ('0.0.0.0', 80) )
s.listen(1)
###################################################################


#QUIT IF BUTTON IS BEING PRESSED(for editing software on restart)##
if pins[0].value() == 0:
###################################################################
    
    while True:
        
        #START CONNECTION######################################################
        cl, addr = s.accept()   #this function will run until someone connects
        print ('client   connected   from ', addr )
        cl_file = cl.makefile ('rwb ', 0)
        while True:
            line = cl_file.readline ()
            if not line or line == b'\r\n':
                break
        ######################################################################
            
        #SET LED ACCORDING TO TEMP#################################
        temperature = temp_c(i2c.readfrom_mem(address,temp_reg,2))
        if temperature < 26:
            green(np)
        elif temperature < 27:
            yellow(np)
        else:
            red(np)
        #############################################################

        #SEND WEBPAGE TO CLIENT################################################################
        rows = ['<tr><td> %s </td><td> %d </td></tr>' % (str(p), p.value()) for p in pins]
        rows.append('<tr><td> %s </td><td > %d </td></tr>' % ("Temperature",temperature))
        response = html % '\n'.join(rows)
        cl.send( response )
        ####################################################################################
        
        #CLOSE CONNECTION
        cl.close()