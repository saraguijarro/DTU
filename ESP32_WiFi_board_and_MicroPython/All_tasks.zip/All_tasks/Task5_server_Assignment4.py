import machine
import network
import socket
import neopixel
import json

address = 24
temp_reg = 5
res_reg = 8


#CODE FOR HARDWARE###############################################
i2c = machine.I2C(scl = machine.Pin(22),sda = machine.Pin(23))
np = neopixel.NeoPixel(machine.Pin(27),3)
inPins = [machine.Pin(39, machine.Pin.IN)]

def green(neopixel):
    neopixel[0] = (255,0,0)
    neopixel[1] = (255,0,0)
    neopixel[2] = (255,0,0)
    np.write()

def yellow(neopixel):
    neopixel[0] = (255,255,0)
    neopixel[1] = (255,255,0)
    neopixel[2] = (255,255,0)
    np.write()

def red(neopixel):
    neopixel[0] = (0,255,0)
    neopixel[1] = (0,255,0)
    neopixel[2] = (0,255,0)
    np.write()
ledFuns = {"green":green, "yellow":yellow, "red":red}
green(np)

def temp_c(data):
    value = data[0] << 8 | data[1]
    temp = (value & 0xFFF) / 16.0
    if value & 0x1000:
        temp -= 256.0
    return temp
#################################################################


#CODE FOR GETTING AND SETTING RESOURCES IN API
def getData(path,api):
    pointer = api
    for res in path:
        pointer = pointer[res.lower()]
    return pointer

def setData(path,value,api):
    pointer = api
    for res in path[:-1]:
        pointer = pointer[res.lower()]
    pointer[path[-1].lower()] = value
    return api
##########################################


#SET UP WIFI ON SERVER#########################
ap = network.WLAN( network.AP_IF )
ap.active( True )
ap.config( essid = 'PyWifi' )
ap.config( authmode = 3, password = "12345678")
##############################################


#GENERIC WEBPAGE#####################################################################
html = """<!DOCTYPE  html>
<html>
    <head><title> ESP32  Pins </title></head>
    <body><h1> ESP32  Pins </h1 >
        <table border = "1"><tr><th> Pin </th><th> Value </th></tr> %s  </table>
     </body>
</html>
"""
#####################################################################################


#SET UP SOCKET FOR NETWORK COMS
s = socket.socket()
s.bind( ('0.0.0.0', 80) )
s.listen(1)
###############################


#INITIALIZE API########################################
api = {"output":{"temp" : 0},"input":{"led" : "green"}}
for pin in inPins:
    api["output"][str(pin).lower()] = 0
#######################################################


if inPins[0].value() == 0:
    while True:
        
        #ACCEPT CLIENT CONNECTION##################
        cl, addr = s.accept()
        print ('client   connected   from ', addr )
        ###########################################
        
        
        #GET CLIENT REQUEST###########
        http = str(cl.recv(4096))[2:]
        lines = http.split("\\r\\n")
        ##############################
        
        
        #PARSE COMMAND AND PATH FROM REQUEST##############
        try:
            command, path = str(lines[0]).split(" ")[0:2]
            path = list(filter(None,path.split("/")))
        except:
            cl.send("HTTP/1.1 400 Bad request\n")
            cl.close()
            continue
        #################################################
        
        
        #FIND MESSAGE BODY###########
        index = -1
        while lines[index] == "":
            index -= 1
        body = lines[index][:-1]
        ############################
        
        
        #UPDATE API AND HTML RESPONSE########################################################################
        temperature = temp_c(i2c.readfrom_mem(address,temp_reg,2))
        for pin in inPins:
            api["output"][str(pin).lower()] = pin.value()
        api["output"]["temp"] = temperature
        
        rows = ['<tr><td> %s </td><td> %d </td></tr>' % (str(p), api["output"][str(p).lower()]) for p in inPins]
        rows.append('<tr><td> %s </td><td > %d </td></tr>' % ("Temperature",temperature))
        response = "HTTP/1.1 200 OK\nContent-Type: text/html\n\n" + (html % '\n'.join(rows))
        ####################################################################################################
        
        
        #GET RESOURCE FROM API###########################################################################
        if command == "GET":
            if not(path == []):
                try:
                    value = getData(path,api)
                    response = "HTTP/1.1 200 OK\nContent-Type: json\n\n" + json.dumps(value)
                except:
                    response = "HTTP/1.1 404 Not Found\n"
        ##############################################################################################
        #SET RESOURCE IN API###########################################################################
        elif command == "PUT":
            try:
                api = setData(path,body,api)
                response = "HTTP/1.1 200 OK\n"
            except:
                response = "HTTP/1.1 404 Path Not Found\n"
        ##############################################################################################
            
        
        #SEND RESPONSE AND CLOSE CONNECTION
        cl.send( response )
        cl.close()
        ####################################
        
        
        #UPDATE LED COLOR#########################
        try:
            ledFuns[api["input"]["led"].lower()](np)
        except:
            print("not valid color")
        #############################################
        