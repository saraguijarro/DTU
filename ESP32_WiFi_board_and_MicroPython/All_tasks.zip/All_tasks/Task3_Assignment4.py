import machine
import network
import socket
import neopixel
import json

address = 24
temp_reg = 5
res_reg = 8

#CODE FOR HARDWARE###############################################
i2c = machine.I2C(scl = machine.Pin(22),sda = machine.Pin(23))
np = neopixel.NeoPixel(machine.Pin(27),3)
pins = [machine.Pin(39, machine.Pin.IN)]

def green(neopixel):
    neopixel[0] = (255,0,0)
    neopixel[1] = (255,0,0)
    neopixel[2] = (255,0,0)
    np.write()

def yellow(neopixel):
    neopixel[0] = (255,255,0)
    neopixel[1] = (255,255,0)
    neopixel[2] = (255,255,0)
    np.write()

def red(neopixel):
    neopixel[0] = (0,255,0)
    neopixel[1] = (0,255,0)
    neopixel[2] = (0,255,0)
    np.write()

def temp_c(data):
    value = data[0] << 8 | data[1]
    temp = (value & 0xFFF) / 16.0
    if value & 0x1000:
        temp -= 256.0
    return temp
#################################################################


#FUNCTION FOR GETTING RESOURCE FROM API AT PATH#################
def getData(path,api):
    pointer = api
    for res in path:
        pointer = pointer[res]
    return pointer
#################################################################


#START SERVER WIFI###############################################
ap = network.WLAN( network.AP_IF )
ap.active( True )
ap.config( essid = 'PyWifi' )
ap.config( authmode = 3, password = "12345678")
################################################################


#GENERIC HTML PAGE###################################################
html = """<!DOCTYPE  html>
<html>
    <head><title> ESP32  Pins </title></head>
    <body><h1> ESP32  Pins </h1 >
        <table border = "1"><tr><th> Pin </th><th> Value </th></tr> %s  </table>
     </body>
</html>
"""
####################################################################


#OPEN SOCKET FOR NETWORK COMMUNICATION##############################
s = socket.socket()
s.bind( ('0.0.0.0', 80) )
s.listen(1)
####################################################################

#we have chosen a very simple API with just the fields temp and pin(39) for now. This is 
#because we only use one pin in boolean mode for the button and one in analog for the temperature sensor.
#We have tried to write the code such that it would be easy to expand this if more pins were connected.
api = {"temp" : 0}
for pin in pins:
    api[str(pin)] = 0



if pins[0].value() == 0:
    while True:
        
        #START CONNECTION WITH CLIENT#####################
        cl, addr = s.accept()
        print ('client   connected   from ', addr )
        cl_file = cl.makefile ('rwb ', 0)
        ##################################################

        #PARSE CLIENT REQUEST#########################################
        command, path = str(cl_file.readline())[2:].split(" ")[0:2]
        path = list(filter(None,path.split("/")))
        ##############################################################
        
        #IGNORE REQUEST HEADER AND BODY#########################
        while True:
            line = cl_file.readline()
            if not line or line == b'\r\n':
                break
        ########################################################
        
        
        #UPDATE API################################################
        temperature = temp_c(i2c.readfrom_mem(address,temp_reg,2))
        for pin in pins:
            api[str(pin)] = pin.value()
        api["temp"] = temperature
        #############################################################
            
        #CONSTRUCT HTML PAGE####################################################################
        rows = ['<tr><td> %s </td><td> %d </td></tr>' % (str(p), api[str(p)]) for p in pins]
        rows.append('<tr><td> %s </td><td > %d </td></tr>' % ("Temperature",temperature))
        response = "HTTP/1.1 200 OK\nContent-Type: text/html\n\n" + (html % '\n'.join(rows))
        ########################################################################################
        
        
        #FIND CORRECT RESOURCE###############################################################
        if command == "GET":
            if not(path == []): #give html page if resource path is empty
                try:
                    value = getData(path,api)
                    response = "HTTP/1.1 200 OK\nContent-Type: json\n\n" + json.dumps(value)
                except:
                    response = "HTTP/1.1 404 Not Found \n"
        ######################################################################################
        
        #SEND RESPONSE AND CLOSE CONNECTION
        cl.send( response )
        cl.close()
        ###################################
        
        #UPDATE LEDS#########################################################################
        if temperature < 26:
            green(np)

        elif temperature < 27:
            yellow(np)
        
        else:
            red(np)
        ####################################################################################